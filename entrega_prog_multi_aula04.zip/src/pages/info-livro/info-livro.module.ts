import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfoLivroPage } from './info-livro';

@NgModule({
  declarations: [
    InfoLivroPage,
  ],
  imports: [
    IonicPageModule.forChild(InfoLivroPage),
  ],
})
export class InfoLivroPageModule {}
