import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Livro } from '../../model/Livro';
import { InfoLivroPage } from '../info-livro/info-livro';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public livros : Livro [];

  constructor(public navCtrl: NavController) {
    this.livros = [
      {nome: "harry Potter", autor: "J.K", img: "harry.png", descricao:"Harry Potter é uma historia de um menino que descobre aos 11 anos de idade ser um bruxo."},
      {nome: "Corações Acorrentados", autor: "Nina Gurgel", img: "coracao.gif",descricao:"Vivendo em um mundo em reconstrução, Jean Cerisier, Príncipe Herdeiro de lIe Écarlat..."},
      {nome: "A ultima dança", autor: "Nicholas Sparks", img: "danca.png",descricao:" Alex deixou um grande legado de dança para entre os quais uma famosa coreografia criada há sete anos, mas jamais apresentada..."},
      {nome: "Game of Thrones", autor: "George R.R Marrtin", img: "got.png",descricao:"Numa terra onde os verões podem durar vários anos e o inverno toda uma vida, as reivindicações e as forças sobrenaturais correm as portas do Reino dos Sete Reinos..."},
      {nome: "The 100", autor: "Kass Morgan", img: "100.png",descricao:" após uma guerra nuclear devastadora que dizimou quase toda a vida na Terra. Os sobreviventes conhecidos são os moradores de doze estações espaciais em órbita da Terra..."},
      {nome: "Divergente", autor: "Veronica Roth", img: "div.png",descricao:"Divergente se passa em uma Chicago futurística destruída após uma guerra. Para manter a paz os fundadores construiram uma cerca e dividiram a população em cinco grupos denominados facções..."},
      
     ];
  }
  
  vai (livro:Livro){
    this.navCtrl.push(InfoLivroPage, {livroSelecionado: livro});
    }

}
